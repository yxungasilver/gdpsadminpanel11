<?php
  /*

  Copyright JeffreyG, JeffreyGMD, Gabriel Páez
  Todos los derechos reservados. 2018 - Actualidad.

  */

  $version = '<center><br><br><h3>Admin Panel by <a href="http://github.com/yxungasilver" target="_blank">yxungasilver (ORIGINAL BY JeffreyG)</a> (v1.0)</h3><center>'; // No interfiere con nada, sólo son créditos. Me haría feliz que no borraras esto. =')
?>
