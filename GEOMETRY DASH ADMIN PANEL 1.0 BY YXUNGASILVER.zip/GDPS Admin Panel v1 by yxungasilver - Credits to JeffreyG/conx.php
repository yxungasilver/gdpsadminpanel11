<?php
// Database Config
$servername = ""; // Your server(GDPS)'s host, you can leave it localhost, or change it (example sql.7m.pl).
$username = ""; // Username of your GDPS Database (example db-user19470)
$pw = ""; // Password of your GDPS Database (example tuu26vdsknntrommcxvas)
$dbname = ""; // The name of your GDPS Database (example db-user19470)

// Security
$seguro = "" // This will be a password type, which should be done doing actions within your private server database. Take good care of it and share it ONLY with people of TOTAL confidence.
?>
