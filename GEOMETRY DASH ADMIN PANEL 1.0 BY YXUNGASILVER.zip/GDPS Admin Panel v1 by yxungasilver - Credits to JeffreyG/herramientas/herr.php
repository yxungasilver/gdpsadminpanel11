<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>GDPS Admin Panel (Dashboard)</title>
	<link rel="stylesheet" href="CSS/estilos.css">
	<link rel="stylesheet" href="CSS/layout.css">
	<link rel="stylesheet" href="CSS/desplegable.css">
	<link rel="stylesheet" href="CSS/fonts.css">
</head>
<body>
	<center><a href="add.php">ADD MOD</a><br>
	<a href="updt.php">UPDATE MOD</a><br>
	<a href="del.php">REMOVE MOD</a><br>
	<a href="acc.php">DELETE ACCOUNT</a><br>
	<a href="dowYlks.php">UPDATE LEVEL STATS</a>
	<?php
	require "../version/ver.php";
	echo $version;
	?>
	
	
     <a href="https://github.com/JeffreyRandom/AdminGDPS">Credits</a>
</body>
</html>
