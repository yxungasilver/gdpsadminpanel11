<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>DELETE ACCOUNT</title>
	<link rel="stylesheet" href="CSS/estilos.css">
	<link rel="stylesheet" href="CSS/layout.css">
	<link rel="stylesheet" href="CSS/desplegable.css">
	<link rel="stylesheet" href="CSS/fonts.css">
</head>
<body>
	<center><h1>DELETE ACCOUNT</h1>
	<h1><a href="herr.php">Another</a> tool?</h1>
	<form action="delAcc.php" method="post">
		AccountID: <br>
		<input type="text" name="accountid"><br>
		Security password: <br>
		<input type="password" name="password"><br><br>
		<input type="submit" value="DELETE ACCOUNT"><br><br>
		<a href="../help/index.php">Help</a>...
	</form></center>
	<?php
	require "../version/ver.php";
	echo $version;
	?>
</body>
</html>
