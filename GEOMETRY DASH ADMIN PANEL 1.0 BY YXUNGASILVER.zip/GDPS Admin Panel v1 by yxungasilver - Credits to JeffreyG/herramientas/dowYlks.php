<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>UPDATE LEVEL STATS</title>
	<link rel="stylesheet" href="CSS/estilos.css">
	<link rel="stylesheet" href="CSS/layout.css">
	<link rel="stylesheet" href="CSS/desplegable.css">
	<link rel="stylesheet" href="CSS/fonts.css">
</head>
<body>
	<center><h1>UPDATE DOWNLOADS AND LIKES</h1>
	<h1><a href="herr.php">Another</a> tool?</h1>
	<form action="updtDown.php" method="post">
		levelID: <br>
		<input type="text" name="levelid"><br>
		Downloads: <br>
		<input type="text" name="descargas"><br>
		Likes: <br>
		<input type="text" name="likes"><br>
		Security password: <br>
		<input type="password" name="password"><br><br>
		<input type="submit" value="Update"><br><br>
		<a href="../help/index.php">Help</a>...
	</form></center>
	<?php
	require "../version/ver.php";
	echo $version;
	?>
</body>
</html>
