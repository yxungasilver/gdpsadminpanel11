Original made by JeffreyG. https://github.com/JeffreyRandom/AdminGDPS
  Copyright JeffreyG, JeffreyGMD, Gabriel Páez
  Todos los derechos reservados. 2018 - Actualidad.



<?php
  /*

  Copyright JeffreyG, JeffreyGMD, Gabriel Páez
  Todos los derechos reservados. 2018 - Actualidad.

  */

  $version = '<center><br><br><h3>AdminGDPS by <a href="http://jeffreyg.rf.gd/index" target="_blank">JeffreyG</a> (v0.7)</h3><center>'; // No interfiere con nada, sólo son créditos. Me haría feliz que no borraras esto. =')
?>
