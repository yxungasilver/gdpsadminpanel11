<?php
	header("Location: herramientas/herr.php");
?>
<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>GDPS Admin Panel</title>
  	<link rel="stylesheet" href="CSS/estilos.css">
  	<link rel="stylesheet" href="CSS/layout.css">
  	<link rel="stylesheet" href="CSS/desplegable.css">
  	<link rel="stylesheet" href="CSS/fonts.css">
  </head>
  <body>
		<?php require "version/ver.php" ?>
		<?php require "credits/index.php" ?>
  </body>
</html>
