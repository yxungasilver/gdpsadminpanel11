# AdminGDPS
Just by adding these files to your Geometry Dash Private Server you will have control over the accounts and moderators of your server.

# Requirements
* Have a Geometry Dash Private Server.
  * The files must be those of [Cvolton](https://github.com/Cvolton/GMDprivateServer).
* GDPS Version +2.1
  * This so that all tool functions [herramientas](./herramientas) are available. (Quests, Gauntlets [COMING SOON])


# Set Up
Hello! Hello JeffreyG / JeffreyGMD. Thank you for downloading this GDPS administrator! <br>
I tried to make it as simple as possible for anyone. Then I'll tell you the first thing you should do to make this work. <br><br>



1.Go to the file conx.php and change the data to the database of your GDPS. And also the secret password. 
2.After you have the data ready, upload the updated file to the web page. 
3.To verify that the data is correct and that the db (database) is connected to the web page, enter the chkCon.php file from the browser.
4.Delete the index.html DON'T DELETE the file index.php.
5.Come in index.php and enjoy.


*It is only compatible with Cvolton's files [GDPS Cvolton](https://github.com/Cvolton/GMDprivateServer)*




Have a Geometry Dash Private Server.
The files must be those of Cvolton .
GDPS Version +2.1
This so that all tool functions are available. (Quests, Gauntlets [COMING SOON])