<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>AYUDA - INICIO</title>
</head>
<body>
	<a href="accs.php">Cuentas</a><br>
	<a href="assId.php">AssignID</a><br>
	<a href="mods.php">Moderadores</a><br>
	<a href="roleid.php">Roles</a><br>
	<a href="lvls.php">Niveles</a><br>
	<a href="users.php">Usuarios</a><br><br>
	<a href="../herramientas/herr.php">Herramientas</a>
	<?php
	require "../version/ver.php";
	echo $version;
	?>

</body>
</html>
